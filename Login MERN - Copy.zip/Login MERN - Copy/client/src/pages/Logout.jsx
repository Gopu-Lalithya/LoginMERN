import { useState } from 'react'
import axios from 'axios'
import {toast} from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'

export default function Login() {
    const navigate = useNavigate()
    const [data, setData] = useState({
        email: '',
        password: '',
    })
    const [error , setError] = useState(true);
    const logout = async()=>{
        const response = await axios.get('/logout')
        if(response){
         console.log(response.data);
         console.log( localStorage.removeItem(response.data));
         
        }
        else{
         console.log('error');
        }
     }
     return (
    
 
        <>
            <div className="login-page">
                <h1 style={{textAlign:"center"}}>logout</h1>
                <button className='logout-btn' onClick={logout}>
                    Log Out
                </button>
            </div>
        </>
      )
    }
