import { useState } from "react";
import "./Login.css";
import axios from "axios";
import { toast } from "react-hot-toast";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState(true);

  // console.log(data);

  const loginUser = async (e) => {
    e.preventDefault();
    const { email, password } = data;
    try {
      const token = localStorage.getItem("token");
      const response = await axios.post(
        "/login",
        {
          email,
          password,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log('token from route',response.data)

      if (response) {
        localStorage.setItem("token", response.data);
        setData({});
        navigate("/dashboard");
        console.log(response.data.token);
      } else {
        console.log("password not match");
        toast.error(data.error);
      }
      console.log(token);

    } catch (error) {
      console.log(error);
    }
  };
  const loginwithgoogle = () => {
    window.open("http://localhost:8000/auth/google/callback", "_self");
  };
  const logout = async () => {
    const response = await axios.post("/logout");
    if (response) {
      console.log(response.data);
      console.log(localStorage.removeItem(response.data));
    } else {
      console.log("error");
    }
  };

  //console.log('data',data);
  return (
    <>
      <div className="login-page">
        <h1 style={{ textAlign: "center" }}>Login</h1>
        <div className="form">
          <form className="login-form" onSubmit={loginUser}>
            <label>Email</label>
            <input
              type="email"
              placeholder="Enter Email..."
              value={data.email}
              onChange={(e) => setData({ ...data, email: e.target.value })}
            />
            <label>Password</label>
            <input
              type="password"
              required
              placeholder="Enter Password..."
              value={data.password}
              onChange={(e) => setData({ ...data, password: e.target.value })}
            />
            {error ? "" : <p>pss</p>}
            <button type="submit">Login</button>
            <p className="message">
              Not Registerd? <a href="../register">Create an account</a>
            </p>
          </form>
          <button className="login-with-google-btn" onClick={loginwithgoogle}>
            Sign In With Google
          </button>
        </div>
        <button className="logout-btn" onClick={logout}>
          Log Out
        </button>
      </div>
    </>
  );
}
