module.exports = {
    JWT_SECRET : 'qwertyuiop'
}