const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const GOOGLE_CLIENT_ID = '712596047889-cabqn012p1g3dia8039a46naqsj487mk.apps.googleusercontent.com'
const GOOGLE_CLIENT_SECRET = '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'

passport.use(new GoogleStrategy({
    clientID: GOOGLE_CLIENT_ID,
    clientSecret: GOOGLE_CLIENT_SECRET,
    callbackURL: "http://localhost:8000/auth/google/callback",
    scope:["profile","email"]
  },
  async(accessToken, refreshToken, profile, done) => {
    try {
      let user = await userdb.findOne({googleId:profile.id});

      if(!user){
          user = new userdb({
              googleId:profile.id,
              displayName:profile.displayName,
              email:profile.emails[0].value,
              image:profile.photos[0].value
          });

          await user.save();
      }

      return done(null,user)
  } catch (error) {
      return done(error,null)
  }
  }
));

passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(user, done) {
    done(null, user);
});
