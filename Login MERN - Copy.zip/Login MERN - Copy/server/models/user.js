const mongoose = require('mongoose')
// const{schema} = mongoose
const schema = mongoose.Schema;

const userSchema = new schema({
    name: String,
    email:{
        type: String,
        unique: true
    },
    password: 
    {
        require: true,
        type:String,
    },
    Image: String,
    googleId: String
})

const UserModel = mongoose.model('user', userSchema);

module.exports = UserModel;