const jwt = require('jsonwebtoken');
const config = require('../config/config');
const User = require('../models/user');

const auth = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
        return res.status(401).json({ message: 'No token, authorization denied' });
    }

    try {
        const token = authHeader.split(' ')[1];
        if (!token) {
            return res.status(401).json({ message: 'No token, authorization denied' });
        }

        const decoded = jwt.verify(token, config.jwtKey);

        let user = await User.findById(decoded.id).select('-password');
        if (!user) {
            user = await Faculty.findById(decoded.id).populate('documents').select('-password');
        }

        if (!user) {
            return res.status(401).json({ message: 'Token is not valid' });
        }

        req.user = user;

        // console.log('Authenticated user:', req.user); // Debug logging

        next();
    } catch (err) {
        console.error('Authentication error:', err.message); // Log the error for debugging
        res.status(401).json({ message: 'Token is not valid' });
    }
};

module.exports = auth;