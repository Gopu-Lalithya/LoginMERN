const User = require("../models/user");
const bcrypt  = require('bcrypt');
const { hashPassword, comparePassword } = require("../helpers/auth");
const jwt = require('jsonwebtoken');
const config = require("../config/config");
var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./scratch');
// const auth = require('../Authentication/Authent');

const test = (req, res) => {
  res.json("test is working");
};

// Register Endpoint
const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    //check if name was entered
    if (!name) {
      return res.json({
        error: "name is required",
      });
    }
    //check email
    const exist = await User.findOne({ email });
    if (exist) {
      return res.json({
        error: "Email is taken already",
      });
    } else if (!email) {
      return res.json({
        error: "Enter the email",
      });
    }
    //check password
    if (!password || password.length < 8) {
      return res.json({
        error: "password is required and should be atlest 8 characters long",
      });
    }
    
    const hashedPassword = await hashPassword(password);
    //create user in datavbase
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
    });
    return res.json(user);
  } catch (error) {
    console.log(error);
  }
};


//Login Endpoint
const loginUser = async (req, res) => {
  try {
    const {email, password} = req.body;

    // check if user exists
    const user = await User.findOne({email});
    if(!user) {
      return res.json({
        error: 'No user found'
      })
    }

    //Check if passwords match
    const match = await comparePassword(password, user.password)
    if(match) {
    const token = jwt.sign({email: user.email, id: user._id, name: user.name}, config.JWT_SECRET);
    console.log(token);
    res.json(token)
    }
    if(!match) {
      res.json({
        error: "Passwords do not match"
      })
    }
  } catch (error) {
     console.log(error)
  }
}

const getProfile = (req, res) => {
const {token} = req.cookies
if(token) {
  jwt.verify(token, process.env.JWT_SECRET, {}, (err, user) => {
    if(err) throw err;
    res.json(user)
    // console.log(token)
  })
} else {
  res.json(null)
}
}

const logoutUser = async(req, res) => {
  const {token} = req.cookies
  localStorage.removeItem(token);
  }



module.exports = {
  test,
  registerUser,
  loginUser,
  getProfile,
  logoutUser
};
