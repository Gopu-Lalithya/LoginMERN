const express = require('express');
const dotenv = require('dotenv').config()
const cors = require('cors')
const {mongoose} = require('mongoose')
const cookieParser = require('cookie-parser');
const passport = require('passport');
const session = require("express-session");
const UserModel = require('./models/user');
//const { JsonWebTokenError } = require('jsonwebtoken');
const { getProfile } = require('./controllers/authController');
const OAuth2Strategy = require("passport-google-oauth20").Strategy;
const jwt = require('jsonwebtoken');
//require('./passport.js');
const app = express();
//database connection
mongoose.connect(process.env.MONGO_URL)
.then(() => console.log('Database is Connected'))
.catch((err) => console.log('Database not connected',err))

//middleware
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({extended: false}))


app.use('/', require('./routes/authRoutes'))

//Setup session
app.use(session({
  secret:"631263727233",
  resave:false,
  saveUninitialized:true
}))

//Setup Passort
app.use(passport.initialize());
app.use(passport.session());

// const GOOGLE_CLIENT_ID = '712596047889-cabqn012p1g3dia8039a46naqsj487mk.apps.googleusercontent.com'
// const GOOGLE_CLIENT_SECRET = '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'

passport.use(
    new OAuth2Strategy({
        clientID:process.env.GOOGLE_CLIENT_ID,
        clientSecret:process.env.GOOGLE_CLIENT_SECRET,
        callbackURL:"/auth/google/callback",
        scope:["profile","email"]
    },
    async(accessToken,refreshToken,profile,done)=>{
        try {
            let user = await UserModel.findOne({googleId:profile.id});

            if(!user){
                user = new UserModel({
                    googleId:profile.id,
                    name:profile.displayName,
                    email:profile.emails[0].value,
                    image:profile.photos[0].value
                });

                await user.save();
            }

            return done(null,user);
        } catch (error) {
            return done(error,null)
        }
    }
    )
)

passport.serializeUser((user,done)=>{
    done(null,user);
})

passport.deserializeUser((user,done)=>{
    done(null,user);
});



//auth google
app.get('/auth/google',
  passport.authenticate('google', {scope: ['email', 'profile']})
)

app.get("/auth/google/callback",passport.authenticate("google",{
   successRedirect:"http://localhost:5173/dashboard",
  failureRedirect:"http://localhost:5173/login",
}))



app.post("/googleLogin/sucess",async(req,res)=>{

  if(req.user){
      res.status(200).json({user:req.user})
      jwt.sign({email: user.email,googleId: user.googleId, name: user.name}, process.env.JWT_SECRET, {}, (err, token) => {
                if(err) throw err;
                res.cookie('token', token).json(user);
                localStorage.setItem(token);
                console.log(token)
              })
  } else{
      res.status(400).json({message:"Not Authorized"})
  }

})

app.get("/login/sucess", getProfile)




const port = 8000;
app.listen(port,() => console.log(`server is running on port ${port}`))